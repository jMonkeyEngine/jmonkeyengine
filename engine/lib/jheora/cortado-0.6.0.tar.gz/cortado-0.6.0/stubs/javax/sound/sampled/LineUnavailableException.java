package javax.sound.sampled;		  

public class LineUnavailableException extends Exception {
    public LineUnavailableException() {
	super();
    }
    public LineUnavailableException(String message) {
	super(message);
    }
}

