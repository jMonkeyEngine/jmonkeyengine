/* JKate
 * Copyright (C) 2008 ogg.k.ogg.k <ogg.k.ogg.k@googlemail.com>
 *
 * Parts of JKate are based on code by Wim Taymans <wim@fluendo.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public License
 * as published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

package com.fluendo.jkate;

/**
 * A style definition.
 */

public class Style
{
  public double halign;
  public double valign;

  public Color text_color;
  public Color background_color;
  public Color draw_color;

  public KateSpaceMetric font_metric;
  public double font_width;
  public double font_height;

  public KateSpaceMetric margin_metric;
  public double left_margin;
  public double top_margin;
  public double right_margin;
  public double bottom_margin;

  public boolean bold;
  public boolean italics;
  public boolean underline;
  public boolean strike;
  public boolean justify;
  public KateWrapMode wrap_mode;

  public String font;
}
